import axios from "axios";
import React, { useEffect, useState } from "react";
import { createContext } from "react";
import useLocalState from "../hooks/useLocalState";
import { authInitialState } from "../utils/constants";

export const AuthContext = createContext();

const AuthContextProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useLocalState("token");
  const [loading, setLoading] = useState(true);
  const api = axios.create();

  console.log("User state: ", user);

  const signup = async (userData) => {
    const res = await api.post(
      `http://localhost:8080/auth/${userData.role}/register`,
      userData
    );
    console.log(res);
    return res.data;
  };

  const updateUser = (user) => {
    setUser(prev => ({ ...prev, user }));
  }

  const saveJobs = (job) => {
    setUser(prev => ({ ...prev, savedJobs: [...prev.savedJobs, job] }));
  }

  const login = async (userData) => {
    return api
      .post(`http://localhost:8080/auth/${userData.role}/login`, userData)
      .then((res) => {
        if (res.status === 200) {
          setToken(res.data.token);
          return true;
        }
      })
      .catch((err) => {
        setToken(null);
        console.log(err);
        return false;
      });
  };

  const logout = () => {
    setToken(null);
  };

  const getUser = async () => {
    return api
      .get("http://localhost:8080/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        setLoading(false);
        if (res.status === 200) {
          setUser({ ...res.data });
        }
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
        setUser(null);
      });
  };

  useEffect(() => {
    let id;
    if (token) {
      setLoading(true);
      id = setTimeout(() => {
        getUser();
      }, 1000);
    } else {
      setLoading(false);
      setUser(null);
    }

    return () => clearTimeout(id);
  }, [token]);

  return (
    <AuthContext.Provider value={{ user, loading, signup, login, logout, saveJobs, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContextProvider;
