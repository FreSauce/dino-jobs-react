const authInitialState = {
  user: { email: "suvanth", role: "manager" },
};
const jobs = [{
  id: '21213',
  company: 'Company',
  role: 'Software Engineer',
  description: 'hehe im desc',
  location: 'Banglore',
  employees: '34-34',
  salary: 90000,
  remote: true,
  req_skills: ['C', 'C++', 'Java'],
  req_experience: 1
}, {
  id: '213323',
  company: 'Company',
  role: 'Software Engineer',
  description: 'hehe im desc',
  location: 'Banglore',
  employees: '34-34',
  salary: 90000,
  remote: true,
  req_skills: ['C', 'C++', 'Java'],
  req_experience: 1
}, {
  id: '345344',
  company: 'Company',
  role: 'Software Engineer',
  description: 'hehe im desc',
  location: 'Banglore',
  employees: '34-34',
  salary: 90000,
  remote: true,
  req_skills: ['C', 'C++', 'Java'],
  req_experience: 1
}]

export { authInitialState, jobs };
